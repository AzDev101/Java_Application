
package chapter10_assignment;

public abstract class Shape {
    public abstract String toString();
}
