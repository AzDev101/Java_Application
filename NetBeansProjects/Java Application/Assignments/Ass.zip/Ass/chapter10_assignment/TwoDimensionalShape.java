
package chapter10_assignment;

public abstract class TwoDimensionalShape extends Shape {
    public abstract double getArea();
}
