import java.util.Scanner;

public class SalaryCalculator_20 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            System.out.print("Enter employee " + (i + 1) + "'s hours worked: ");
            double hoursWorked = scanner.nextDouble();

            System.out.print("Enter employee " + (i + 1) + "'s hourly rate: ");
            double hourlyRate = scanner.nextDouble();

            double grossPay;
            if (hoursWorked <= 40) {
                grossPay = hoursWorked * hourlyRate;
            } else {
                grossPay = 40 * hourlyRate + (hoursWorked - 40) * hourlyRate * 1.5;
            }

            System.out.printf("Employee %d's gross pay: $%.2f%n%n", i + 1, grossPay);
        }
    }
}
