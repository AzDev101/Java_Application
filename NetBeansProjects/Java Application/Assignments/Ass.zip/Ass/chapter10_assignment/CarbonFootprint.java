
package chapter10_assignment;

public interface CarbonFootprint {
    double getCarbonFootprint();
}
